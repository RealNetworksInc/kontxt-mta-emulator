#/bin/bash

messageText=`cat $1`

echo "open 3.221.209.195 443"
sleep 2
echo "HELO dal-icmms-mqueue002.syniverse.com"
echo "MAIL From:<+15073401279/TYPE=PLMN@icmms1.sun5.lightsurf.net>"
sleep 2
echo "RCPT To:<+16128057032/TYPE=PLMN@vzwpix.com>"
sleep 2
echo "DATA"
sleep 2
echo $messageText
echo "\r"
sleep 2
echo "."
sleep 2
echo "\r"

